var searchData=
[
  ['global',['Global',['../structhusky_1_1Context_1_1Global.html',1,'husky::Context']]]
];
