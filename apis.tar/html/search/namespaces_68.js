var searchData=
[
  ['husky',['husky',['../namespacehusky.html',1,'']]]
];
