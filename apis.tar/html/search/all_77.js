var searchData=
[
  ['workerinfo',['WorkerInfo',['../classhusky_1_1WorkerInfo.html',1,'husky']]],
  ['workernodefactory',['WorkerNodeFactory',['../classhusky_1_1WorkerNodeFactory.html',1,'husky']]]
];
