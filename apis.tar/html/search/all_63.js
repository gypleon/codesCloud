var searchData=
[
  ['centralrecver',['CentralRecver',['../classhusky_1_1CentralRecver.html',1,'husky']]],
  ['config',['Config',['../classhusky_1_1Config.html',1,'husky']]],
  ['coordinator',['Coordinator',['../classhusky_1_1Coordinator.html',1,'husky']]]
];
